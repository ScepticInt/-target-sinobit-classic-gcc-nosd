## yotta Target Description using GCC to compile for Nordic nRF51822 16KB device.
- without SoftDevice

